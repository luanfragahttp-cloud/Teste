# VI$IONARIO V1 — Android

Aplicativo offline para finanças do trabalho como taxista/motorista de aplicativo. Projeto Android nativo em Java, banco SQLite local, sem login ou serviço remoto. Pacote: `br.com.visionario.app`; Android 8.0+ (API 26).

## Funcionalidades implementadas

- **Meu dia:** data selecionável; cartão de faturamento com lápis para lançar/editar total de corridas e valores diários por origem. Bruto é a soma das origens; não existe lançamento por corrida nem por meio de pagamento.
- **Fontes:** Táxi/Aeroporto, InDrive, Uber, 99, Outros. Novas fontes podem ser adicionadas; ocultar uma fonte preserva o histórico.
- **Despesas:** etanol, gasolina, GNV, outro combustível, alimentação, pedágio, estacionamento, multa e outros; cada lançamento tem valor e observação opcional e pode ser excluído mediante confirmação.
- **Turnos:** início exige KM inicial; pausa/retomada desconta o tempo; encerramento exige KM final e valida que não retrocedeu. É possível ter vários turnos por dia. Um indicador discreto de turno ativo aparece nas telas. O turno ativo e as pausas persistem no banco entre aberturas do app. Também há lançamento manual com data, início, fim, pausa e KM inicial/final. Um fim anterior ao início significa madrugada do dia seguinte.
- **Diária/PDA:** R$ 218 de segunda a sábado; domingo sem diária. PDA de R$ 150 toda quarta, ativável e editável com dia da semana configurável. Ajustes são versionados pela data de vigência. O fechamento grava a cobrança aplicada para que alterações posteriores não mudem um dia fechado. A cobrança é aplicada aos dias efetivamente fechados.
- **Relatórios:** filtros dia, semana, mês, ano e período, com bruto, despesas, diária/PDA, saldo, corridas, horas e KM.
- **Formato:** valores persistidos em centavos, KM em metros, tempo em milissegundos; data local ISO no banco. A interface recebe reais com vírgula e horas no formato 24h, incluindo `0800`.

## Build

Abra esta pasta no Android Studio com SDK Platform 35, JDK 17 e Gradle 8.9+ configurados. Sincronize e execute `:app:assembleDebug` (ou `./build-apk.sh` quando houver Gradle instalado). O resultado será `app/build/outputs/apk/debug/app-debug.apk`, assinado com a chave de depuração para instalação direta. No celular, permita a instalação pelo aplicativo que abrir o arquivo.

Rode `./test-domain.sh` para testar as regras sem Android. O script usa o compilador do módulo `jdk.compiler` presente no Java 17.

## Estado desta entrega

O código e os testes de regras foram preparados, mas **nenhum APK foi gerado neste ambiente**: o Android SDK, o Gradle e o empacotador de APK não estão disponíveis, e o repositório de download do SDK não é acessível. As imagens aprovadas e a foto original foram recuperadas. A V1 inclui uma nova ilustração cartoon baseada nelas na abertura. A interface foi aproximada com cartões e cores do print, mas a reprodução exata ainda depende de comparação visual em Android real. Não há tela de login porque a V1 local não tem contas.

A compilação e o teste num aparelho Android ainda são necessários antes de considerar a V1 pronta para instalação. A V1 usa o banco local SQLite e não contém exportação/backup de dados.

## Build na nuvem

O arquivo `.github/workflows/android-apk.yml` prepara Java 17, Gradle 8.9 e Android SDK 35 no GitHub Actions. Ele testa as regras, compila o APK debug, verifica a assinatura e disponibiliza `VISIONARIO-V1.apk` como artefato. Esse fluxo foi preparado, mas ainda não executado. Requer um repositório GitHub autorizado com Actions habilitado. A compilação pode ser iniciada pelo botão **Run workflow** ou por envio à branch `main`.
