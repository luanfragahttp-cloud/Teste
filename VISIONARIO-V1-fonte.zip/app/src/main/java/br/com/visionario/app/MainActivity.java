package br.com.visionario.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import br.com.visionario.domain.Rules;
import java.time.*;
import java.time.format.*;
import java.util.*;

public final class MainActivity extends Activity {
    private static final int GREEN=Color.rgb(14,184,104), RED=Color.rgb(238,69,83), BLUE=Color.rgb(37,111,235), INK=Color.rgb(26,39,57), MUTED=Color.rgb(106,119,135), BG=Color.WHITE;
    private Store store;private LinearLayout page,bar;private String day=LocalDate.now().toString();private String tab="dia";private Handler handler=new Handler();
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);store=new Store(this);show("dia");}
    @Override protected void onDestroy(){handler.removeCallbacksAndMessages(null);store.close();super.onDestroy();}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable shape(int color){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(19));return d;}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    private void gap(LinearLayout l,int n){View v=new View(this);l.addView(v,new LinearLayout.LayoutParams(1,dp(n)));}
    private LinearLayout card(){LinearLayout l=column();l.setPadding(dp(18),dp(17),dp(18),dp(17));l.setBackground(shape(Color.rgb(247,249,252)));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,dp(12));page.addView(l,p);return l;}
    private Button button(String s,int color,Runnable onClick){Button b=new Button(this);b.setText(s);b.setTextSize(14);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setBackground(shape(color));b.setOnClickListener(v->safe(onClick));return b;}
    private void safe(Runnable r){try{r.run();}catch(Exception e){new AlertDialog.Builder(this).setTitle("Confira os dados").setMessage(e.getMessage()==null?"Não foi possível concluir.":e.getMessage()).setPositiveButton("OK",null).show();}}
    private void addButton(LinearLayout l,String title,int color,Runnable run){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(49));p.topMargin=dp(9);l.addView(button(title,color,run),p);}
    private void show(String target){tab=target;handler.removeCallbacksAndMessages(null);LinearLayout root=column();root.setBackgroundColor(BG);setContentView(root);
        LinearLayout head=column();head.setPadding(dp(20),dp(18),dp(20),dp(12));root.addView(head);head.addView(text("VI$IONARIO",26,GREEN,true));head.addView(text("Seu trabalho, seus números.",13,MUTED,false));
        if(store.openShift()!=0){TextView floating=text("● Turno ativo · tocar para abrir",12,BLUE,true);floating.setPadding(dp(12),dp(8),dp(12),dp(8));floating.setBackground(shape(Color.rgb(235,243,255)));head.addView(floating);floating.setOnClickListener(v->show("turno"));}
        ScrollView scroll=new ScrollView(this);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));page=column();page.setPadding(dp(18),dp(10),dp(18),dp(16));scroll.addView(page);
        switch(target){case "dia":dashboard();break;case "turno":shift();break;case "lancamentos":transactions();break;case "relatorio":reports();break;case "ajustes":settings();break;}
        bar=new LinearLayout(this);bar.setPadding(dp(6),dp(5),dp(6),dp(7));root.addView(bar);nav("Início","dia");nav("Lançamentos","lancamentos");nav("Relatórios","relatorio");nav("Mais","ajustes");
    }
    private void nav(String label,String dest){TextView t=text(label,12,tab.equals(dest)?BLUE:MUTED,tab.equals(dest));t.setGravity(Gravity.CENTER);t.setPadding(dp(2),dp(13),dp(2),dp(13));bar.addView(t,new LinearLayout.LayoutParams(0,dp(47),1));t.setOnClickListener(v->show(dest));}
    private void heading(String title,String sub){page.addView(text(title,23,INK,true));page.addView(text(sub,13,MUTED,false));gap(page,17);}
    private String pretty(String key){LocalDate d=LocalDate.parse(key);return d.format(DateTimeFormatter.ofPattern("EEEE, dd 'de' MMMM",new Locale("pt","BR")));}
    private void pickDate(){LocalDate d=LocalDate.parse(day);new DatePickerDialog(this,(v,y,m,n)->{day=LocalDate.of(y,m+1,n).toString();show("dia");},d.getYear(),d.getMonthValue()-1,d.getDayOfMonth()).show();}
    private void dashboard(){heading("Meu dia","Toque na data para navegar pelo histórico.");LinearLayout select=card();addButton(select,pretty(day)+"  ▾",BLUE,this::pickDate);
        long[] a=store.totals(day,day);long balance=a[0]-a[1]-a[2];
        LinearLayout c=card();c.setBackground(shape(GREEN));c.addView(text("Ganhos do dia",14,Color.WHITE,false));c.addView(text(Rules.money(a[0]),31,Color.WHITE,true));addButton(c,"✎  Lançar / editar fechamento",GREEN,this::closing);
        LinearLayout costs=card();costs.setBackground(shape(RED));costs.addView(text("Despesas do dia",14,Color.WHITE,false));costs.addView(text(Rules.money(a[1]),25,Color.WHITE,true));costs.addView(text("Diária + PDA: "+Rules.money(a[2]),13,Color.WHITE,false));addButton(costs,"+  Adicionar despesa",RED,this::addExpense);
        LinearLayout net=card();net.setBackground(shape(BLUE));net.addView(text("Saldo do dia",14,Color.WHITE,false));net.addView(text(Rules.money(balance),29,Color.WHITE,true));net.addView(text(a[3]+" corridas  •  "+Rules.duration(a[4])+" trabalhadas  •  "+String.format(Locale.ROOT,"%.1f",a[5]/1000.0)+" km",13,Color.WHITE,false));
        LinearLayout actions=card();addButton(actions,"Fechamento do dia",BLUE,this::closing);addButton(actions,"Turno e KM",GREEN,()->show("turno"));addButton(actions,"Relatórios",BLUE,()->show("relatorio"));
        if(store.openShift()!=0){LinearLayout live=card();live.addView(text("●  Turno em andamento",15,BLUE,true));addButton(live,"Abrir cronômetro",BLUE,()->show("turno"));}
        LinearLayout breakdown=card();breakdown.addView(text("Ganhos por origem",17,INK,true));try(Cursor q=store.getReadableDatabase().rawQuery("SELECT s.name,i.cents FROM income i JOIN source s ON s.id=i.source_id WHERE i.date=? ORDER BY s.name",new String[]{day})) {while(q.moveToNext())breakdown.addView(text(q.getString(0)+"  ·  "+Rules.money(q.getLong(1)),14,GREEN,false));}
        LinearLayout entries=card();entries.addView(text("Despesas lançadas",17,INK,true));try(Cursor q=store.getReadableDatabase().rawQuery("SELECT id,category,cents,note FROM expense WHERE date=? ORDER BY id DESC",new String[]{day})) {while(q.moveToNext()){long id=q.getLong(0);LinearLayout row=column();row.addView(text(q.getString(1)+"  ·  "+Rules.money(q.getLong(2)),14,RED,false));if(!q.getString(3).isEmpty())row.addView(text(q.getString(3),12,MUTED,false));addButton(row,"Excluir lançamento",MUTED,()->new AlertDialog.Builder(this).setMessage("Excluir esta despesa?").setNegativeButton("Cancelar",null).setPositiveButton("Excluir",(d,w)->safe(()->{store.deleteExpense(id);show("dia");})).show());entries.addView(row);gap(entries,8);}}
    }
    private EditText field(LinearLayout parent,String label,String value,boolean numeric){parent.addView(text(label,13,MUTED,true));EditText e=new EditText(this);e.setSingleLine(true);e.setText(value);e.setTextSize(17);if(numeric)e.setInputType(8194);parent.addView(e,new LinearLayout.LayoutParams(-1,dp(48)));return e;}
    private LinearLayout dialogBody(){LinearLayout box=column();box.setPadding(dp(20),dp(7),dp(20),dp(5));ScrollView scroll=new ScrollView(this);scroll.addView(box);LinearLayout wrap=column();wrap.addView(scroll,new LinearLayout.LayoutParams(-1,dp(430)));return box;}
    private String moneyInput(long cents){return String.format(new Locale("pt","BR"),"%.2f",cents/100.0);}
    private void closing(){LinearLayout body=dialogBody();int rides=(int)store.scalar("SELECT rides FROM day WHERE date=?",day);EditText count=field(body,"Total de corridas",String.valueOf(rides),true);
        ArrayList<Long> ids=new ArrayList<>();ArrayList<EditText> fields=new ArrayList<>();try(Cursor q=store.getReadableDatabase().rawQuery("SELECT id,name FROM source WHERE enabled=1 OR id IN (SELECT source_id FROM income WHERE date=?) ORDER BY id",new String[]{day})) {while(q.moveToNext()){long id=q.getLong(0);ids.add(id);long cents=store.scalar("SELECT cents FROM income WHERE date=? AND source_id=?",day,""+id);fields.add(field(body,q.getString(1)+" (R$)",moneyInput(cents),true));}}
        new AlertDialog.Builder(this).setTitle("Fechamento · "+day).setView(body.getParent() instanceof ScrollView?(View)body.getParent().getParent():body).setNegativeButton("Cancelar",null).setPositiveButton("Salvar",(d,w)->safe(()->{
            int n=Integer.parseInt(count.getText().toString().trim());long[] values=new long[ids.size()];for(int i=0;i<values.length;i++)values[i]=Rules.cents(fields.get(i).getText().toString());
            store.saveClosing(day,n,ids,values);show("dia");
        })).show();
    }
    private void addExpense(){String[] categories={"Etanol","Gasolina","GNV","Combustível (outro)","Alimentação","Pedágio","Estacionamento","Multa","Outros"};LinearLayout box=column();box.setPadding(dp(20),0,dp(20),0);Spinner cat=new Spinner(this);ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,categories);cat.setAdapter(adapter);box.addView(cat);EditText value=field(box,"Valor (R$)","",true);EditText note=field(box,"Observação (opcional)","",false);
        new AlertDialog.Builder(this).setTitle("Nova despesa · "+day).setView(box).setNegativeButton("Cancelar",null).setPositiveButton("Salvar",(d,w)->safe(()->{store.expense(day,(String)cat.getSelectedItem(),Rules.cents(value.getText().toString()),note.getText().toString().trim());show("dia");})).show();
    }
    private void transactions(){heading("Lançamentos","Movimentos de "+pretty(day));LinearLayout controls=card();addButton(controls,"Lançar / editar ganhos",GREEN,this::closing);addButton(controls,"+ Despesa",RED,this::addExpense);addButton(controls,"Turnos e KM",BLUE,()->show("turno"));
        LinearLayout list=card();list.addView(text("Ganhos",17,GREEN,true));try(Cursor q=store.getReadableDatabase().rawQuery("SELECT s.name,i.cents FROM income i JOIN source s ON s.id=i.source_id WHERE i.date=? AND i.cents>0 ORDER BY s.name",new String[]{day})){while(q.moveToNext())list.addView(text(q.getString(0)+"  +"+Rules.money(q.getLong(1)),15,INK,false));}
        gap(list,12);list.addView(text("Despesas",17,RED,true));try(Cursor q=store.getReadableDatabase().rawQuery("SELECT category,cents FROM expense WHERE date=? ORDER BY id DESC",new String[]{day})){while(q.moveToNext())list.addView(text(q.getString(0)+"  -"+Rules.money(q.getLong(1)),15,INK,false));}}
    private void shift(){heading("Turno de trabalho","Cronômetro, pausas, KM e múltiplos turnos.");long id=store.openShift();LinearLayout c=card();if(id==0){c.addView(text("Nenhum turno em andamento",16,INK,true));addButton(c,"Iniciar turno",GREEN,()->kmDialog(true));}else{
        String started=store.string("SELECT started FROM shift WHERE id=?",""+id);long start=Long.parseLong(started);long pause=store.scalar("SELECT COALESCE(pause_started,0) FROM shift WHERE id=?",""+id);TextView clock=text("00:00",36,BLUE,true);c.addView(clock);c.addView(text("Início: "+Instant.ofEpochMilli(start).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("dd/MM HH:mm")),13,MUTED,false));
        Runnable tick=new Runnable(){public void run(){if(!"turno".equals(tab))return;long sid=store.openShift();if(sid==0)return;String date=store.string("SELECT date FROM shift WHERE id=?",""+sid);clock.setText(Rules.duration(store.shiftTotals(date)[0]));handler.postDelayed(this,1000);}};handler.post(tick);
        addButton(c,pause==0?"Pausar":"Retomar",BLUE,()->{store.pause(pause!=0);show("turno");});addButton(c,"Encerrar turno",RED,()->kmDialog(false));}
        LinearLayout manual=card();manual.addView(text("Lançamento manual",17,INK,true));manual.addView(text("Horários em 24h; pausas são descontadas.",13,MUTED,false));addButton(manual,"+  Adicionar turno manual",BLUE,this::manualShift);
        LinearLayout history=card();history.addView(text("Turnos de "+day,17,INK,true));try(Cursor q=store.getReadableDatabase().rawQuery("SELECT started,ended,km_start,km_end,paused_ms FROM shift WHERE date=? ORDER BY started",new String[]{day})) {while(q.moveToNext()){String start=Instant.ofEpochMilli(q.getLong(0)).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("HH:mm"));String end=q.isNull(1)?"em andamento":Instant.ofEpochMilli(q.getLong(1)).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("HH:mm"));history.addView(text(start+" → "+end+"  ·  "+String.format(Locale.ROOT,"%.1f",q.getLong(2)/1000.0)+" → "+(q.isNull(3)?"…":String.format(Locale.ROOT,"%.1f",q.getLong(3)/1000.0))+" km",14,INK,false));}}
    }
    private void kmDialog(boolean start){LinearLayout box=column();box.setPadding(dp(20),0,dp(20),0);EditText km=field(box,start?"KM inicial obrigatório":"KM final obrigatório","",true);new AlertDialog.Builder(this).setTitle(start?"Iniciar turno":"Encerrar turno").setView(box).setNegativeButton("Cancelar",null).setPositiveButton("Confirmar",(d,w)->safe(()->{if(start)store.start(LocalDate.now().toString(),Rules.metres(km.getText().toString()));else store.finish(Rules.metres(km.getText().toString()));show("turno");})).show();}
    private void manualShift(){LinearLayout box=dialogBody();EditText date=field(box,"Data (AAAA-MM-DD)",day,false);EditText a=field(box,"Início (0800 ou 08:00)","",false);EditText b=field(box,"Fim (1700 ou 17:00)","",false);EditText p=field(box,"Pausas (minutos)","0",true);EditText x=field(box,"KM inicial","",true);EditText y=field(box,"KM final","",true);
        new AlertDialog.Builder(this).setTitle("Turno manual").setView((View)box.getParent().getParent()).setNegativeButton("Cancelar",null).setPositiveButton("Salvar",(d,w)->safe(()->{
            String key=LocalDate.parse(date.getText().toString().trim()).toString();ZoneId zone=ZoneId.systemDefault();long start=LocalDateTime.of(LocalDate.parse(key),LocalTime.parse(Rules.time(a.getText().toString()))).atZone(zone).toInstant().toEpochMilli();long end=LocalDateTime.of(LocalDate.parse(key).plusDays(LocalTime.parse(Rules.time(b.getText().toString())).isBefore(LocalTime.parse(Rules.time(a.getText().toString())))?1:0),LocalTime.parse(Rules.time(b.getText().toString()))).atZone(zone).toInstant().toEpochMilli();
            store.manual(key,start,end,Rules.metres(x.getText().toString()),Rules.metres(y.getText().toString()),Rules.minutes(p.getText().toString())*60000L);day=key;show("turno");
        })).show();
    }
    private void reports(){heading("Relatórios","Ganhos, gastos e produtividade.");LinearLayout filters=card();String[] choices={"Dia","Semana","Mês","Ano","Período"};Spinner s=new Spinner(this);s.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,choices));filters.addView(s);EditText from=field(filters,"De (AAAA-MM-DD)",day,false);EditText to=field(filters,"Até (AAAA-MM-DD)",day,false);addButton(filters,"Ver relatório",BLUE,()->{
            LocalDate d=LocalDate.parse(day);String begin=from.getText().toString().trim(),end=to.getText().toString().trim();switch(s.getSelectedItemPosition()){
                case 0:begin=day;end=day;break;case 1:begin=d.minusDays(d.getDayOfWeek().getValue()-1).toString();end=d.plusDays(7-d.getDayOfWeek().getValue()).toString();break;
                case 2:begin=d.withDayOfMonth(1).toString();end=d.withDayOfMonth(d.lengthOfMonth()).toString();break;case 3:begin=d.withDayOfYear(1).toString();end=d.withDayOfYear(d.lengthOfYear()).toString();break;
            }showReport(begin,end);
        });
    }
    private void showReport(String start,String end){long[] a=store.totals(LocalDate.parse(start).toString(),LocalDate.parse(end).toString());LinearLayout l=card();l.addView(text(start+" → "+end,15,INK,true));gap(l,10);for(String line:new String[]{"Bruto: "+Rules.money(a[0]),"Despesas: "+Rules.money(a[1]),"Diárias e PDA: "+Rules.money(a[2]),"Saldo: "+Rules.money(a[0]-a[1]-a[2]),"Corridas: "+a[3],"Horas: "+Rules.duration(a[4]),"KM: "+String.format(Locale.ROOT,"%.1f",a[5]/1000.0)}){l.addView(text(line,18,line.startsWith("Saldo")?BLUE:INK,false));gap(l,5);}}
    private void settings(){heading("Ajustes","Mudanças de valores valem a partir de hoje.");Store.Policy p=store.policyAt(LocalDate.now().toString());LinearLayout c=card();c.addView(text("Diária e PDA",17,INK,true));c.addView(text("Diária: segunda a sábado · "+Rules.money(p.daily)+"\nPDA: "+(p.active?"ativo · "+Rules.money(p.pda)+" · dia "+p.weekday:"desativado"),14,MUTED,false));addButton(c,"Editar valores futuros",BLUE,()->editPolicy(p));
        LinearLayout origins=card();origins.addView(text("Fontes de ganho",17,INK,true));try(Cursor q=store.getReadableDatabase().rawQuery("SELECT id,name,enabled FROM source ORDER BY id",null)){while(q.moveToNext()){long id=q.getLong(0);boolean enabled=q.getInt(2)==1;addButton(origins,q.getString(1)+(enabled?"  ✓":"  (oculta)"),enabled?GREEN:MUTED,()->{store.toggleSource(id,!enabled);show("ajustes");});}}addButton(origins,"+  Nova fonte",BLUE,this::newSource);
    }
    private void editPolicy(Store.Policy p){LinearLayout box=column();box.setPadding(dp(20),0,dp(20),0);EditText daily=field(box,"Diária (segunda a sábado, R$)",moneyInput(p.daily),true);EditText pda=field(box,"PDA (R$)",moneyInput(p.pda),true);CheckBox enabled=new CheckBox(this);enabled.setText("PDA ativo");enabled.setChecked(p.active);box.addView(enabled);Spinner weekday=new Spinner(this);weekday.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Segunda","Terça","Quarta","Quinta","Sexta","Sábado","Domingo"}));weekday.setSelection(p.weekday-1);box.addView(weekday);
        new AlertDialog.Builder(this).setTitle("Valores a partir de hoje").setView(box).setNegativeButton("Cancelar",null).setPositiveButton("Salvar",(d,w)->safe(()->{store.policy(LocalDate.now().toString(),Rules.cents(daily.getText().toString()),Rules.cents(pda.getText().toString()),enabled.isChecked(),weekday.getSelectedItemPosition()+1);show("ajustes");})).show();
    }
    private void newSource(){EditText input=new EditText(this);input.setSingleLine(true);new AlertDialog.Builder(this).setTitle("Nova fonte de ganho").setView(input).setNegativeButton("Cancelar",null).setPositiveButton("Salvar",(d,w)->safe(()->{store.source(input.getText().toString());show("ajustes");})).show();}
}
