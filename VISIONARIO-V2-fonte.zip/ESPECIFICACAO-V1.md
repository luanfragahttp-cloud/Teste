# Documento Mestre — VI$IONARIO V1

## Objetivo
Controle financeiro exclusivo do trabalho de taxista/motorista de aplicativo, separado das finanças pessoais. Entregar aplicativo Android instalável como ponto de partida para melhorias.

## Fechamento
Em **Meu dia**, selecionar uma data para ver o painel completo; o lápis abre o fechamento daquele dia. Registrar total de corridas e faturamento diário por origem (Táxi/Aeroporto, InDrive, Uber, 99 e Outros, com fontes configuráveis). Não exigir cadastro de cada corrida nem discriminar por forma de pagamento. Bruto é a soma das origens. Despesas são lançamentos por categoria. Saldo = bruto − despesas variáveis − diária/PDA aplicada.

## Trabalho
Cronômetro discreto: iniciar, pausar, retomar e encerrar. KM inicial obrigatório para iniciar, KM final obrigatório para encerrar; calcular distância e tempo útil, retirando pausas. Múltiplos turnos por dia e alternativa de horários manuais em 24h (`0800` vira `08:00`). Suportar turno que termina após meia-noite.

## Recorrências
Diária padrão de R$ 218, de segunda a sábado; domingo livre. PDA padrão de R$ 150 às quartas, ativável, com valor e dia configuráveis. Mudanças devem preservar o valor aplicado aos dias já fechados e valer dali em diante.

## Despesas e relatórios
Combustíveis: etanol, gasolina, GNV e outro. Variáveis: alimentação, pedágio, estacionamento, multa e outros. Relatórios para dia, semana, mês, ano e intervalo, com bruto, despesas, recorrências, saldo, corridas, horas e KM.

## Visual
Nome exato **VI$IONARIO**. Fundo branco; verde vivo para ganhos, vermelho vivo para despesas e azul para saldo/destaques; cartões arredondados e transições leves. Logo cartoon baseada na foto do usuário, envolvendo dinheiro e elementos digitais, exibida na abertura. A colagem aprovada e a foto foram recuperadas; uma nova ilustração cartoon derivada dessas referências foi incluída na abertura. A reprodução exata das demais telas depende de validação em aparelho.

## Critérios de aceitação restantes
Compilar APK debug assinado; instalar e testar em Android real; conferir os fluxos e as telas com o print aprovado; conferir a arte cartoon no aparelho.
