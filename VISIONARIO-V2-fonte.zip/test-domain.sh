#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p /tmp/visionario-domain-classes
java com.sun.tools.javac.Main -d /tmp/visionario-domain-classes domain/src/main/java/br/com/visionario/domain/Rules.java domain/src/test/java/br/com/visionario/domain/RulesTest.java
java -cp /tmp/visionario-domain-classes br.com.visionario.domain.RulesTest
