#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ -x ./gradlew ]]; then runner=./gradlew; elif command -v gradle >/dev/null; then runner=gradle; else echo 'Gradle indisponível. Instale Android Studio (SDK 35) e Gradle 8.9+, ou adicione o Gradle Wrapper.' >&2; exit 1; fi
"$runner" :app:assembleDebug
printf 'APK: %s\n' "$PWD/app/build/outputs/apk/debug/app-debug.apk"
