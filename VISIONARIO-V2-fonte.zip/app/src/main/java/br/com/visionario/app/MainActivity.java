package br.com.visionario.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.view.*;
import android.widget.*;
import java.time.*;
import java.util.*;
import br.com.visionario.domain.Rules;

/** Phase 1: real native Android home and opening; the existing SQLite database stays intact. */
public final class MainActivity extends Activity {
    Store store; NativeUi ui; FrameLayout safeRoot; View splash; final Handler clock=new Handler(Looper.getMainLooper());
    String day=LocalDate.now().toString(); boolean homeReady=false; long shownAt;
    @Override public void onCreate(Bundle saved){super.onCreate(saved);ui=new NativeUi(this);store=new Store(this);if(saved!=null)day=saved.getString("day",day);
        getWindow().setStatusBarColor(Color.WHITE);getWindow().setNavigationBarColor(Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        safeRoot=new FrameLayout(this);safeRoot.setBackgroundColor(Color.WHITE);setContentView(safeRoot);
        if(Build.VERSION.SDK_INT>=30){getWindow().setDecorFitsSystemWindows(false);safeRoot.setOnApplyWindowInsetsListener((v,ins)->{Insets n=ins.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());v.setPadding(n.left,n.top,n.right,n.bottom);return ins;});}else safeRoot.setFitsSystemWindows(true);
        if(Build.VERSION.SDK_INT>=31)getSplashScreen().setOnExitAnimationListener(v->v.remove());
        if(saved!=null){homeReady=true;renderHome();}else showSplash();
    }
    void showSplash(){FrameLayout panel=new FrameLayout(this);panel.setBackgroundColor(0xff061017);panel.setTag("native-splash");NativeUi.Art art=new NativeUi.Art(this,new Rect(21,36,294,646),true,0);panel.addView(art,new FrameLayout.LayoutParams(-1,-1));art.setContentDescription("VI$IONARIO. Seu trabalho, seu controle, seu futuro.");
        ProgressBar progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setProgressTintList(android.content.res.ColorStateList.valueOf(0xff00ec56));progress.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff3a6270));progress.setProgress(82);FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(ui.dp(175),ui.dp(5),Gravity.CENTER_HORIZONTAL|Gravity.BOTTOM);p.bottomMargin=ui.dp(22);panel.addView(progress,p);
        safeRoot.addView(panel,new FrameLayout.LayoutParams(-1,-1));splash=panel;shownAt=SystemClock.elapsedRealtime();clock.postDelayed(()->{homeReady=true;renderHome();},1800);
    }
    @Override protected void onResume(){super.onResume();if(homeReady)renderHome();}
    @Override public void onSaveInstanceState(Bundle out){out.putString("day",day);super.onSaveInstanceState(out);}
    @Override protected void onDestroy(){clock.removeCallbacksAndMessages(null);store.close();super.onDestroy();}
    void open(String screen){Intent i=new Intent(this,ExistingScreensActivity.class).putExtra("screen",screen).putExtra("day",day);startActivity(i);overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);}
    void chooseDay(){LocalDate date=LocalDate.parse(day);DatePickerDialog dialog=new DatePickerDialog(this,(p,y,m,d)->{day=LocalDate.of(y,m+1,d).toString();renderHome();},date.getYear(),date.getMonthValue()-1,date.getDayOfMonth());dialog.show();}
    String dateLabel(){LocalDate d=LocalDate.parse(day);String[] weekdays={"Seg","Ter","Qua","Qui","Sex","Sáb","Dom"};String[] months={"Janeiro","Fevereiro","Março","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"};return weekdays[d.getDayOfWeek().getValue()-1]+", "+d.getDayOfMonth()+" de "+months[d.getMonthValue()-1]+" de "+d.getYear();}
    void renderHome(){safeRoot.removeAllViews();LinearLayout root=ui.column();root.setBackgroundColor(Color.WHITE);root.setTag("native-home");safeRoot.addView(root,new FrameLayout.LayoutParams(-1,-1));
        boolean compact=getResources().getConfiguration().screenHeightDp<740;int metricHeight=compact?77:86,tileHeight=compact?88:96;
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(ui.dp(17),ui.dp(6),ui.dp(17),ui.dp(6));header.setContentDescription("VI$IONARIO");
        NativeUi.Art avatar=new NativeUi.Art(this,new Rect(639,40,706,112),true,0);header.addView(avatar,new LinearLayout.LayoutParams(ui.dp(54),ui.dp(62)));ui.click(avatar,()->open("more"));avatar.setContentDescription("Abrir Mais");
        NativeUi.Art wordmark=new NativeUi.Art(this,new Rect(708,48,881,93),true,0);LinearLayout.LayoutParams wp=new LinearLayout.LayoutParams(0,ui.dp(51),1);wp.leftMargin=ui.dp(1);wp.rightMargin=ui.dp(9);header.addView(wordmark,wp);wordmark.setContentDescription("VI$IONARIO");
        FrameLayout bell=new FrameLayout(this);NativeUi.Glyph bellIcon=ui.glyph("bell",NativeUi.BLUE,26);bell.addView(bellIcon,new FrameLayout.LayoutParams(ui.dp(26),ui.dp(26),Gravity.CENTER));header.addView(bell,new LinearLayout.LayoutParams(ui.dp(40),ui.dp(48)));bell.setContentDescription("Notificações");ui.click(bell,()->open("notifications"));root.addView(header,new LinearLayout.LayoutParams(-1,ui.dp(76)));View line=new View(this);line.setBackgroundColor(NativeUi.LINE);root.addView(line,new LinearLayout.LayoutParams(-1,ui.dp(1)));
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);scroll.setVerticalScrollBarEnabled(false);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));LinearLayout page=ui.column();page.setPadding(ui.dp(18),ui.dp(10),ui.dp(18),ui.dp(14));scroll.addView(page,new ScrollView.LayoutParams(-1,-2));
        LinearLayout dateRow=new LinearLayout(this);dateRow.setGravity(Gravity.CENTER_VERTICAL);TextView date=ui.text(dateLabel(),13,NativeUi.INK,false);dateRow.addView(date,new LinearLayout.LayoutParams(0,ui.dp(35),1));date.setGravity(Gravity.CENTER_VERTICAL);dateRow.addView(ui.glyph("calendar",0xff31556b,20));dateRow.setContentDescription("Selecionar data. "+dateLabel());ui.click(dateRow,this::chooseDay);page.addView(dateRow);ui.gap(page,9);
        long[] totals=store.totals(day,day);long expense=totals[1]+totals[2];String[] labels={"Ganhos do dia","Despesas do dia","Saldo do dia"};long[] amounts={totals[0],expense,totals[0]-expense};int[] colors={NativeUi.GREEN,NativeUi.RED,NativeUi.BLUE},ends={0xff00b21d,0xffff0033,0xff0064ff};String[] symbols={"trend","down","wallet"};for(int i=0;i<3;i++){page.addView(ui.financialCard(labels[i],Rules.money(amounts[i]),colors[i],ends[i],symbols[i],metricHeight),new LinearLayout.LayoutParams(-1,ui.dp(metricHeight)));if(i<2)ui.gap(page,10);}
        ui.gap(page,20);String[][] actions={{"Lançar Ganho","plus","gain"},{"Lançar Despesa","minus","expense"},{"Fechamento do Dia","calendar","closing"},{"Relatórios","chart","reports"}};int[] ac={NativeUi.GREEN,NativeUi.RED,NativeUi.BLUE,NativeUi.GOLD},ae={0xff00af21,0xffff0030,0xff0063ff,0xfff59a00};for(int row=0;row<2;row++){LinearLayout grid=new LinearLayout(this);for(int col=0;col<2;col++){int n=row*2+col;View tile=ui.primaryTile(actions[n][0],actions[n][1],ac[n],ae[n],()->open(actions[n][2]));tile.setTag("action:"+actions[n][2]);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,ui.dp(tileHeight),1);if(col==0)p.rightMargin=ui.dp(12);grid.addView(tile,p);}page.addView(grid);if(row==0)ui.gap(page,12);}ui.gap(page,14);
        FrameLayout shift=new FrameLayout(this);android.graphics.drawable.GradientDrawable bg=ui.rounded(0xfff7faff,9);bg.setStroke(ui.dp(1),0xffe4edf5);shift.setBackground(bg);LinearLayout shiftRow=new LinearLayout(this);shiftRow.setGravity(Gravity.CENTER_VERTICAL);shiftRow.setPadding(ui.dp(12),0,ui.dp(12),0);shiftRow.addView(ui.glyph("clock",0xff4d6b80,20));TextView shiftText=ui.text(store.openShift()==0?"Turno e KM":"Turno em andamento · abrir",12,0xff4d6b80,false);LinearLayout.LayoutParams st=new LinearLayout.LayoutParams(0,-2,1);st.leftMargin=ui.dp(9);shiftRow.addView(shiftText,st);shiftRow.addView(ui.glyph("chevron",0xff4d6b80,15));shift.addView(shiftRow,new FrameLayout.LayoutParams(-1,-1));shift.setContentDescription("Turno e KM");shift.setTag("action:shift");ui.click(shift,()->open("shift"));page.addView(shift,new LinearLayout.LayoutParams(-1,ui.dp(43)));
        View divider=new View(this);divider.setBackgroundColor(NativeUi.LINE);root.addView(divider,new LinearLayout.LayoutParams(-1,ui.dp(1)));root.addView(ui.navigation(s->{switch(s){case "home":break;case "list":open("transactions");break;case "chart":open("reports");break;default:open("more");}}),new LinearLayout.LayoutParams(-1,ui.dp(61)));
        root.setAlpha(0);root.animate().alpha(1).setDuration(160).start();
    }
}
