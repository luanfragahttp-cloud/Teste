package br.com.visionario.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Insets;
import android.net.Uri;
import android.view.*;
import android.webkit.*;
import android.widget.FrameLayout;
import org.json.*;
import java.time.*;
import java.util.*;
import java.io.*;
import br.com.visionario.domain.Rules;

public final class ExistingScreensActivity extends Activity {
    WebView web;
    Store store;
    private static final int EXPORT=40,IMPORT=41;
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        store=new Store(this);
        getWindow().setStatusBarColor(Color.WHITE); getWindow().setNavigationBarColor(Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        FrameLayout root=new FrameLayout(this); root.setBackgroundColor(Color.WHITE);setContentView(root);
        if(Build.VERSION.SDK_INT>=30){
            getWindow().setDecorFitsSystemWindows(false);
            root.setOnApplyWindowInsetsListener((v,insets)->{
                int mask=WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout()|WindowInsets.Type.ime();
                Insets b=insets.getInsets(mask);v.setPadding(b.left,b.top,b.right,b.bottom);
                return new WindowInsets.Builder(insets).setInsets(mask,Insets.NONE).build();
            });
        }else{root.setFitsSystemWindows(true);}
        web=new WebView(this);root.addView(web,new FrameLayout.LayoutParams(-1,-1));
        web.setBackgroundColor(Color.WHITE);web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(false);web.getSettings().setAllowContentAccess(false);
        web.getSettings().setTextZoom(100);web.getSettings().setSupportZoom(false);
        web.addJavascriptInterface(new Bridge(),"Android");
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){return true;}
        });
        web.loadUrl("file:///android_asset/index.html");
    }
    @Override public void onBackPressed(){web.evaluateJavascript("back()",null);}
    @Override protected void onDestroy(){web.destroy();store.close();super.onDestroy();}
    private JSONObject rows(String sql,String...args)throws Exception{
        JSONArray a=new JSONArray();try(Cursor c=store.getReadableDatabase().rawQuery(sql,args)){
            while(c.moveToNext()){JSONObject o=new JSONObject();for(int i=0;i<c.getColumnCount();i++)o.put(c.getColumnName(i),c.isNull(i)?JSONObject.NULL:c.getType(i)==Cursor.FIELD_TYPE_INTEGER?c.getLong(i):c.getString(i));a.put(o);}}
        return new JSONObject().put("rows",a);
    }
    @Override public android.content.SharedPreferences getPreferences(int mode){return getSharedPreferences("br.com.visionario.app.MainActivity",mode);}
    public class Bridge {
        @JavascriptInterface public String initialScreen(){return getIntent().getStringExtra("screen")==null?"home":getIntent().getStringExtra("screen");}
        @JavascriptInterface public String initialDay(){return getIntent().getStringExtra("day")==null?LocalDate.now().toString():getIntent().getStringExtra("day");}
        @JavascriptInterface public String today(){return LocalDate.now().toString();}
        @JavascriptInterface public synchronized String call(String operation,String payload){
            try{
                JSONObject p=new JSONObject(payload),out=new JSONObject();String day=p.optString("day",LocalDate.now().toString());
                LocalDate.parse(day);
                switch(operation){
                    case "state": {
                        String from=p.optString("from",day),to=p.optString("to",day);LocalDate.parse(from);LocalDate.parse(to);
                        long[] t=store.totals(from,to);out.put("totals",new JSONArray(t));
                        out.put("sources",rows("SELECT s.id,s.name,s.enabled,COALESCE(SUM(i.cents),0) cents FROM source s LEFT JOIN income i ON i.source_id=s.id AND i.date BETWEEN ? AND ? GROUP BY s.id ORDER BY s.id",from,to).getJSONArray("rows"));
                        out.put("expenses",rows("SELECT * FROM expense WHERE date BETWEEN ? AND ? ORDER BY date DESC,id DESC",from,to).getJSONArray("rows"));
                        out.put("shifts",rows("SELECT * FROM shift WHERE date=? ORDER BY started DESC",day).getJSONArray("rows"));
                        out.put("closed",store.scalar("SELECT closed FROM day WHERE date=?",day));
                        out.put("rides",store.scalar("SELECT rides FROM day WHERE date=?",day));
                        long open=store.openShift();out.put("active",open==0?JSONObject.NULL:rows("SELECT * FROM shift WHERE id=?",""+open).getJSONArray("rows").getJSONObject(0));
                        Store.Policy policy=store.policyAt(day);out.put("policy",new JSONObject().put("daily",policy.daily).put("pda",policy.pda).put("enabled",policy.active).put("weekday",policy.weekday).put("due",policy.charge(day)));
                        JSONArray trend=new JSONArray();LocalDate d=LocalDate.parse(from),last=LocalDate.parse(to);
                        int stride=Math.max(1,(int)(java.time.temporal.ChronoUnit.DAYS.between(d,last)+1)/31);
                        for(;!d.isAfter(last);d=d.plusDays(stride)){LocalDate stop=d.plusDays(stride-1);if(stop.isAfter(last))stop=last;long[] a=store.totals(d.toString(),stop.toString());trend.put(new JSONObject().put("day",d.toString()).put("gain",a[0]).put("expense",a[1]+a[2]));}out.put("trend",trend);
                        out.put("prefs",new JSONObject(getPreferences(0).getString("profile","{}")));break;
                    }
                    case "income": {
                        long id=p.getLong("id");if(store.scalar("SELECT COUNT(*) FROM source WHERE id=?",""+id)!=1)throw new Exception("Origem não encontrada.");
                        store.income(day,id,Rules.cents(p.getString("value")));break;
                    }
                    case "expense":store.expense(day,p.getString("category"),Rules.cents(p.getString("value")),p.optString("note"));break;
                    case "deleteExpense":store.deleteExpense(p.getLong("id"));break;
                    case "closing":{
                        JSONArray a=p.getJSONArray("values");ArrayList<Long> ids=new ArrayList<>();long[] values=new long[a.length()];for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);ids.add(o.getLong("id"));values[i]=Rules.cents(o.getString("value"));}
                        store.saveClosing(day,p.getInt("rides"),ids,values);break;
                    }
                    case "source":store.source(p.getString("name"));break;
                    case "toggleSource":store.toggleSource(p.getLong("id"),p.getBoolean("enabled"));break;
                    case "policy":store.policy(LocalDate.now().toString(),Rules.cents(p.getString("daily")),Rules.cents(p.getString("pda")),p.getBoolean("enabled"),p.getInt("weekday"));break;
                    case "start":store.start(LocalDate.now().toString(),Rules.metres(p.getString("km")));break;
                    case "pause":store.pause(p.getBoolean("resume"));break;
                    case "finish":store.finish(Rules.metres(p.getString("km")));break;
                    case "manual":{
                        LocalDate date=LocalDate.parse(day);LocalTime start=LocalTime.parse(Rules.time(p.getString("start"))),end=LocalTime.parse(Rules.time(p.getString("end")));
                        long a=date.atTime(start).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli(),b=date.plusDays(end.isBefore(start)?1:0).atTime(end).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
                        store.manual(day,a,b,Rules.metres(p.getString("kmStart")),Rules.metres(p.getString("kmEnd")),Rules.minutes(p.optString("pause","0"))*60000L);break;
                    }
                    case "prefs":getPreferences(0).edit().putString("profile",p.getJSONObject("prefs").toString()).apply();break;
                    case "export":runOnUiThread(()->startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json").putExtra(Intent.EXTRA_TITLE,"VISIONARIO-backup-"+LocalDate.now()+".json"),EXPORT));break;
                    case "import":runOnUiThread(()->new AlertDialog.Builder(ExistingScreensActivity.this).setTitle("Restaurar backup?").setMessage("O arquivo escolhido substituirá os dados desta versão. Exporte um backup antes de continuar.").setNegativeButton("Cancelar",null).setPositiveButton("Escolher arquivo",(d,w)->startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json"),IMPORT)).show());break;
                    case "exit":case "home":runOnUiThread(()->finish());break;
                    default:throw new Exception("Ação não reconhecida.");
                }
                return new JSONObject().put("ok",true).put("data",out).toString();
            }catch(Exception e){return "{\"ok\":false,\"error\":"+JSONObject.quote(e.getMessage()==null?"Confira os dados informados.":e.getMessage())+"}";}
        }
    }
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(result!=RESULT_OK||data==null)return;
        try{
            String[] tables={"source","income","expense","day","shift","policy"};
            if(request==EXPORT){JSONObject o=new JSONObject().put("format","visionario-1").put("prefs",new JSONObject(getPreferences(0).getString("profile","{}")));
                for(String table:tables)o.put(table,rows("SELECT * FROM "+table).getJSONArray("rows"));
                try(OutputStream stream=getContentResolver().openOutputStream(data.getData())){stream.write(o.toString(2).getBytes(java.nio.charset.StandardCharsets.UTF_8));}message("Backup salvo.");
            }else if(request==IMPORT){
                ByteArrayOutputStream bytes=new ByteArrayOutputStream();try(InputStream stream=getContentResolver().openInputStream(data.getData())){byte[] buffer=new byte[4096];int n;while((n=stream.read(buffer))!=-1){bytes.write(buffer,0,n);if(bytes.size()>10000000)throw new Exception("Backup muito grande.");}}
                JSONObject o=new JSONObject(bytes.toString("UTF-8"));if(!"visionario-1".equals(o.getString("format")))throw new Exception("Formato de backup inválido.");
                android.database.sqlite.SQLiteDatabase db=store.getWritableDatabase();db.beginTransaction();try{for(String table:tables){JSONArray list=o.getJSONArray(table);db.delete(table,null,null);for(int i=0;i<list.length();i++){JSONObject row=list.getJSONObject(i);ContentValues v=new ContentValues();Iterator<String> keys=row.keys();while(keys.hasNext()){String k=keys.next();if(row.isNull(k))v.putNull(k);else v.put(k,row.getString(k));}db.insertOrThrow(table,null,v);}}store.policyAt(LocalDate.now().toString());db.setTransactionSuccessful();}finally{db.endTransaction();}
                getPreferences(0).edit().putString("profile",o.optJSONObject("prefs")==null?"{}":o.getJSONObject("prefs").toString()).apply();message("Backup restaurado.");
            }
        }catch(Exception e){message("Não foi possível concluir: "+e.getMessage());}
    }
    void message(String text){web.evaluateJavascript("notify("+JSONObject.quote(text)+");render()",null);}
}
