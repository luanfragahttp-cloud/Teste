package br.com.visionario.app;

import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.content.res.ColorStateList;
import android.view.*;
import android.widget.*;

/** Native, reusable visual components. Artwork is drawn from the official reference without regenerating it. */
final class NativeUi {
    static final int GREEN=0xff00bf20, RED=0xffff0736, BLUE=0xff087bff, GOLD=0xffffad00, INK=0xff182330, MUTED=0xff667887, LINE=0xffedf0f3;
    final Context c;
    NativeUi(Context context){c=context;}
    int dp(float n){return Math.round(n*c.getResources().getDisplayMetrics().density);}
    LinearLayout column(){LinearLayout v=new LinearLayout(c);v.setOrientation(LinearLayout.VERTICAL);return v;}
    TextView text(String value,float size,int color,boolean bold){TextView t=new TextView(c);t.setText(value);t.setTextSize(size);t.setTextColor(color);t.setFontFeatureSettings("tnum");t.setIncludeFontPadding(false);t.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));return t;}
    GradientDrawable rounded(int color,float radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    GradientDrawable gradient(int color,int end,float radius){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{color,end});d.setCornerRadius(dp(radius));return d;}
    void click(View v,Runnable action){v.setClickable(true);v.setFocusable(true);v.setOnClickListener(x->action.run());v.setStateListAnimator(null);if(v instanceof FrameLayout)((FrameLayout)v).setForeground(new RippleDrawable(ColorStateList.valueOf(0x22ffffff),null,rounded(Color.WHITE,13)));v.setOnTouchListener((x,e)->{if(e.getAction()==MotionEvent.ACTION_DOWN)x.animate().scaleX(.985f).scaleY(.985f).setDuration(75).start();else if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL)x.animate().scaleX(1).scaleY(1).setDuration(110).start();return false;});}
    void gap(LinearLayout parent,int height){parent.addView(new View(c),new LinearLayout.LayoutParams(1,dp(height)));}
    Glyph glyph(String type,int color,int size){Glyph g=new Glyph(c,type,color);g.setLayoutParams(new LinearLayout.LayoutParams(dp(size),dp(size)));g.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);return g;}
    FrameLayout financialCard(String title,String value,int color,int end,String symbol,int height){FrameLayout card=new FrameLayout(c);card.setBackground(gradient(color,end,13));card.setTag("financial:"+title);LinearLayout labels=column();labels.setGravity(Gravity.CENTER_VERTICAL);labels.setPadding(dp(18),0,dp(62),0);TextView label=text(title,15,0xffedfff3,false);labels.addView(label);gap(labels,5);labels.addView(text(value,29,Color.WHITE,true));card.addView(labels,new FrameLayout.LayoutParams(-1,-1));Glyph mark=glyph(symbol,Color.WHITE,38);FrameLayout.LayoutParams mp=new FrameLayout.LayoutParams(dp(38),dp(38),Gravity.RIGHT|Gravity.CENTER_VERTICAL);mp.rightMargin=dp(19);card.addView(mark,mp);card.setContentDescription(title+", "+value);return card;}
    FrameLayout primaryTile(String label,String symbol,int color,int end,Runnable action){FrameLayout tile=new FrameLayout(c);tile.setBackground(gradient(color,end,14));tile.setContentDescription(label);LinearLayout inside=column();inside.setGravity(Gravity.CENTER);Glyph g=glyph(symbol,Color.WHITE,33);inside.addView(g);gap(inside,9);TextView title=text(label,12,Color.WHITE,true);title.setGravity(Gravity.CENTER);inside.addView(title);tile.addView(inside,new FrameLayout.LayoutParams(-1,-1));click(tile,action);return tile;}
    LinearLayout navigation(java.util.function.Consumer<String> navigate){LinearLayout bar=new LinearLayout(c);bar.setBackgroundColor(Color.WHITE);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(3),dp(5),dp(3),dp(3));String[][] items={{"home","Início"},{"list","Lançamentos"},{"chart","Relatórios"},{"more","Mais"}};for(String[] item:items){LinearLayout cell=column();cell.setGravity(Gravity.CENTER);int color=item[0].equals("home")?GREEN:MUTED;cell.addView(glyph(item[0],color,23));gap(cell,4);TextView title=text(item[1],10,color,item[0].equals("home"));cell.addView(title);cell.setContentDescription(item[1]);click(cell,()->navigate.accept(item[0]));bar.addView(cell,new LinearLayout.LayoutParams(0,-1,1));}bar.setTag("bottom-navigation");return bar;}

    static class Art extends View {
        private static Bitmap reference;
        final Rect crop;final boolean contain;final float radius;
        Art(Context c,Rect src,boolean fit,float round){super(c);if(reference==null)reference=BitmapFactory.decodeResource(c.getResources(),R.drawable.official_reference);crop=src;contain=fit;radius=round;setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);Paint paint=new Paint(3);RectF dst=new RectF(0,0,getWidth(),getHeight());if(contain){float scale=Math.min(getWidth()/(float)crop.width(),getHeight()/(float)crop.height());float w=crop.width()*scale,h=crop.height()*scale;dst=new RectF((getWidth()-w)/2,(getHeight()-h)/2,(getWidth()+w)/2,(getHeight()+h)/2);}if(radius>0){Path clip=new Path();float r=radius*getResources().getDisplayMetrics().density;clip.addRoundRect(new RectF(0,0,getWidth(),getHeight()),r,r,Path.Direction.CW);canvas.clipPath(clip);}canvas.drawBitmap(reference,crop,dst,paint);}
    }
    static final class Glyph extends View {
        final String name;final int color;
        Glyph(Context c,String type,int tint){super(c);name=type;color=tint;}
        void path(Canvas c,Paint p,float...xy){Path v=new Path();v.moveTo(xy[0],xy[1]);for(int i=2;i<xy.length;i+=2)v.lineTo(xy[i],xy[i+1]);c.drawPath(v,p);}
        @Override protected void onDraw(Canvas c){super.onDraw(c);c.save();c.scale(getWidth()/24f,getHeight()/24f);Paint p=new Paint(3);p.setColor(color);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.9f);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);
            switch(name){
            case "plus":case "minus":p.setStyle(Paint.Style.FILL);c.drawCircle(12,12,11,p);p.setColor(name.equals("plus")?GREEN:RED);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);path(c,p,7,12,17,12);if(name.equals("plus"))path(c,p,12,7,12,17);break;
            case "trend":path(c,p,3,18,9,11,13,14,21,5);path(c,p,15,5,21,5,21,11);break;
            case "down":path(c,p,3,5,9,12,13,9,21,19);path(c,p,15,19,21,19,21,13);break;
            case "wallet":c.drawRoundRect(3,7,21,21,2,2,p);path(c,p,3,7,16,3,17,7);c.drawRoundRect(14,12,22,17,1,1,p);p.setStyle(Paint.Style.FILL);c.drawCircle(17,14.5f,.9f,p);break;
            case "calendar":c.drawRoundRect(4,5,20,21,2,2,p);path(c,p,8,3,8,7);path(c,p,16,3,16,7);path(c,p,4,10,20,10);path(c,p,8,14,10,14);path(c,p,14,14,16,14);path(c,p,8,17,10,17);break;
            case "home":path(c,p,2,11,12,3,22,11);path(c,p,5,10,5,21,10,21,10,14,14,14,14,21,19,21,19,10);break;
            case "chart":p.setStyle(Paint.Style.FILL);c.drawRoundRect(3,13,7,22,.8f,.8f,p);c.drawRoundRect(10,3,14,22,.8f,.8f,p);c.drawRoundRect(17,8,21,22,.8f,.8f,p);break;
            case "list":path(c,p,5,3,19,3,19,8);path(c,p,19,21,5,21,5,16);path(c,p,5,12,19,12);path(c,p,9,8,5,12,9,16);path(c,p,15,8,19,12,15,16);break;
            case "clock":c.drawCircle(12,12,9,p);path(c,p,12,6,12,12,16,14);break;
            case "bell":Path b=new Path();b.moveTo(5,17);b.lineTo(7,14);b.lineTo(7,8);b.cubicTo(7,1,17,1,17,8);b.lineTo(17,14);b.lineTo(19,17);b.close();c.drawPath(b,p);path(c,p,10,21,14,21);p.setColor(RED);p.setStyle(Paint.Style.FILL);c.drawCircle(19,4,2.5f,p);break;
            case "chevron":path(c,p,9,5,16,12,9,19);break;
            default:p.setStyle(Paint.Style.FILL);c.drawCircle(5,12,1.8f,p);c.drawCircle(12,12,1.8f,p);c.drawCircle(19,12,1.8f,p);
            }c.restore();
        }
    }
}
