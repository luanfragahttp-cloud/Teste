package br.com.visionario.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class SplashActivity extends Activity {
    private final Handler handler=new Handler();
    @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().setStatusBarColor(Color.rgb(0,22,49));getWindow().setNavigationBarColor(Color.rgb(0,16,37));
        FrameLayout root=new FrameLayout(this);setContentView(root);
        ImageView art=new ImageView(this);art.setImageResource(R.drawable.splash_art);art.setScaleType(ImageView.ScaleType.CENTER_CROP);root.addView(art,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout brand=new LinearLayout(this);brand.setOrientation(1);brand.setGravity(Gravity.CENTER);FrameLayout.LayoutParams pos=new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM);pos.bottomMargin=(int)(43*getResources().getDisplayMetrics().density);root.addView(brand,pos);
        TextView logo=new TextView(this);logo.setText("VI$IONARIO");logo.setTextColor(Color.WHITE);logo.setTextSize(39);logo.setTypeface(null,Typeface.BOLD_ITALIC);logo.setShadowLayer(6,2,3,Color.BLACK);brand.addView(logo);
        TextView slogan=new TextView(this);slogan.setText("SEU TRABALHO  •  SEU CONTROLE  •  SEU FUTURO");slogan.setTextColor(Color.WHITE);slogan.setTextSize(10);slogan.setGravity(Gravity.CENTER);brand.addView(slogan);
        handler.postDelayed(()->{startActivity(new Intent(this,MainActivity.class));finish();},1500);
    }
    @Override protected void onDestroy(){handler.removeCallbacksAndMessages(null);super.onDestroy();}
}
