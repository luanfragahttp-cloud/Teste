package br.com.visionario.app;

import android.content.*;
import android.database.*;
import android.database.sqlite.*;
import br.com.visionario.domain.Rules;
import java.time.*;
import java.util.*;

final class Store extends SQLiteOpenHelper {
    Store(Context context) { super(context, "visionario-v1.db", null, 1); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE day(date TEXT PRIMARY KEY, rides INTEGER NOT NULL DEFAULT 0, closed INTEGER NOT NULL DEFAULT 0, charge_cents INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE TABLE source(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, enabled INTEGER NOT NULL DEFAULT 1)");
        db.execSQL("CREATE TABLE income(date TEXT NOT NULL, source_id INTEGER NOT NULL, cents INTEGER NOT NULL CHECK(cents>=0), PRIMARY KEY(date,source_id))");
        db.execSQL("CREATE TABLE expense(id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT NOT NULL, category TEXT NOT NULL, cents INTEGER NOT NULL CHECK(cents>=0), note TEXT NOT NULL DEFAULT '')");
        db.execSQL("CREATE TABLE shift(id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT NOT NULL, started INTEGER NOT NULL, ended INTEGER, km_start INTEGER NOT NULL, km_end INTEGER, paused_ms INTEGER NOT NULL DEFAULT 0, pause_started INTEGER)");
        db.execSQL("CREATE TABLE policy(date TEXT PRIMARY KEY, daily_cents INTEGER NOT NULL, pda_cents INTEGER NOT NULL, pda_active INTEGER NOT NULL, pda_weekday INTEGER NOT NULL)");
        db.execSQL("INSERT INTO policy VALUES('0001-01-01',21800,15000,1,3)");
        for (String s : new String[]{"Táxi/Aeroporto","InDrive","Uber","99","Outros"}) { ContentValues v=new ContentValues(); v.put("name",s); db.insert("source",null,v); }
        db.execSQL("CREATE INDEX shift_date ON shift(date)");
        db.execSQL("CREATE INDEX expense_date ON expense(date)");
    }
    @Override public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion) { throw new IllegalStateException("Migration required"); }
    long scalar(String sql,String... args) { try(Cursor c=getReadableDatabase().rawQuery(sql,args)) { return c.moveToFirst()?c.getLong(0):0; } }
    String string(String sql,String... args) { try(Cursor c=getReadableDatabase().rawQuery(sql,args)) { return c.moveToFirst()?c.getString(0):""; } }
    void day(String date,int rides) { if(rides<0) throw new IllegalArgumentException("Corridas inválidas."); ContentValues v=new ContentValues(); v.put("date",date); v.put("rides",rides); v.put("closed",1); long prior=scalar("SELECT COUNT(*) FROM day WHERE date=? AND closed=1",date); v.put("charge_cents",prior>0?scalar("SELECT charge_cents FROM day WHERE date=?",date):policyAt(date).charge(date)); getWritableDatabase().insertWithOnConflict("day",null,v,SQLiteDatabase.CONFLICT_REPLACE); }
    void saveClosing(String date,int rides,ArrayList<Long> ids,long[] values) {
        if(rides<0||ids.size()!=values.length)throw new IllegalArgumentException("Fechamento inválido.");
        for(long amount:values)if(amount<0)throw new IllegalArgumentException("Valor negativo.");
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try { day(date,rides);for(int i=0;i<values.length;i++)income(date,ids.get(i),values[i]);db.setTransactionSuccessful(); }
        finally { db.endTransaction(); }
    }
    void income(String date,long source,long cents) { if(cents<0) throw new IllegalArgumentException("Valor negativo."); ContentValues v=new ContentValues(); v.put("date",date); v.put("source_id",source); v.put("cents",cents); getWritableDatabase().insertWithOnConflict("income",null,v,SQLiteDatabase.CONFLICT_REPLACE); }
    void expense(String date,String category,long cents,String note) { if(cents<=0) throw new IllegalArgumentException("Informe uma despesa maior que zero."); ContentValues v=new ContentValues(); v.put("date",date); v.put("category",category); v.put("cents",cents); v.put("note",note); getWritableDatabase().insertOrThrow("expense",null,v); }
    void deleteExpense(long id) { getWritableDatabase().delete("expense","id=?",new String[]{""+id}); }
    void source(String name) { if(name.trim().isEmpty()) throw new IllegalArgumentException("Nome obrigatório."); ContentValues v=new ContentValues(); v.put("name",name.trim()); getWritableDatabase().insertOrThrow("source",null,v); }
    void toggleSource(long id,boolean enabled) { ContentValues v=new ContentValues(); v.put("enabled",enabled?1:0); getWritableDatabase().update("source",v,"id=?",new String[]{""+id}); }
    void policy(String date,long daily,long pda,boolean active,int weekday) {
        if(daily<0||pda<0||weekday<1||weekday>7) throw new IllegalArgumentException("Configuração inválida.");
        ContentValues v=new ContentValues();v.put("date",date);v.put("daily_cents",daily);v.put("pda_cents",pda);v.put("pda_active",active?1:0);v.put("pda_weekday",weekday);
        getWritableDatabase().insertWithOnConflict("policy",null,v,SQLiteDatabase.CONFLICT_REPLACE);
    }
    Policy policyAt(String date) { try(Cursor c=getReadableDatabase().rawQuery("SELECT daily_cents,pda_cents,pda_active,pda_weekday FROM policy WHERE date<=? ORDER BY date DESC LIMIT 1",new String[]{date})) {
        if(!c.moveToFirst()) throw new IllegalStateException("Configuração inicial ausente.");return new Policy(c.getLong(0),c.getLong(1),c.getInt(2)==1,c.getInt(3));
    } }
    static final class Policy { final long daily,pda; final boolean active;final int weekday;
        Policy(long d,long p,boolean a,int w){daily=d;pda=p;active=a;weekday=w;}
        long charge(String date){return Rules.allowance(LocalDate.parse(date),daily,pda,active,weekday);}
    }
    long openShift() { return scalar("SELECT id FROM shift WHERE ended IS NULL ORDER BY id DESC LIMIT 1"); }
    void start(String date,long km) {
        if(openShift()!=0) throw new IllegalArgumentException("Encerre o turno em andamento.");
        ContentValues v=new ContentValues();v.put("date",date);v.put("started",System.currentTimeMillis());v.put("km_start",km);getWritableDatabase().insertOrThrow("shift",null,v);
    }
    void pause(boolean resume) {
        long id=openShift();if(id==0) throw new IllegalArgumentException("Nenhum turno em andamento.");
        SQLiteDatabase db=getWritableDatabase();try(Cursor c=db.rawQuery("SELECT paused_ms,pause_started FROM shift WHERE id=?",new String[]{""+id})) {
            c.moveToFirst();long now=System.currentTimeMillis();ContentValues v=new ContentValues();
            if(resume){if(c.isNull(1))throw new IllegalArgumentException("Turno não está pausado.");v.put("paused_ms",c.getLong(0)+now-c.getLong(1));v.putNull("pause_started");}
            else {if(!c.isNull(1))throw new IllegalArgumentException("Turno já está pausado.");v.put("pause_started",now);}
            db.update("shift",v,"id=?",new String[]{""+id});
        }
    }
    void finish(long km) {
        long id=openShift();if(id==0)throw new IllegalArgumentException("Nenhum turno em andamento.");
        SQLiteDatabase db=getWritableDatabase();try(Cursor c=db.rawQuery("SELECT km_start,paused_ms,pause_started FROM shift WHERE id=?",new String[]{""+id})) {
            c.moveToFirst();Rules.kmRange(c.getLong(0),km);long now=System.currentTimeMillis();ContentValues v=new ContentValues();v.put("km_end",km);v.put("ended",now);
            if(!c.isNull(2))v.put("paused_ms",c.getLong(1)+now-c.getLong(2));v.putNull("pause_started");db.update("shift",v,"id=?",new String[]{""+id});
        }
    }
    void manual(String date,long start,long end,long kmStart,long kmEnd,long pauseMs) {
        Rules.kmRange(kmStart,kmEnd);Rules.worked(start,end,pauseMs);
        ContentValues v=new ContentValues();v.put("date",date);v.put("started",start);v.put("ended",end);v.put("km_start",kmStart);v.put("km_end",kmEnd);v.put("paused_ms",pauseMs);getWritableDatabase().insertOrThrow("shift",null,v);
    }
    long[] shiftTotals(String date) { long ms=0,km=0;try(Cursor c=getReadableDatabase().rawQuery("SELECT started,ended,km_start,km_end,paused_ms,pause_started FROM shift WHERE date=?",new String[]{date})) {
        long now=System.currentTimeMillis();while(c.moveToNext()) {long end=c.isNull(1)?now:c.getLong(1);long pause=c.getLong(4)+(c.isNull(5)?0:now-c.getLong(5));ms+=Math.max(0,end-c.getLong(0)-pause);if(!c.isNull(3)) km+=c.getLong(3)-c.getLong(2);}
        }return new long[]{ms,km};
    }
    long[] totals(String start,String end) {
        long income=scalar("SELECT COALESCE(SUM(cents),0) FROM income WHERE date BETWEEN ? AND ?",start,end);
        long expense=scalar("SELECT COALESCE(SUM(cents),0) FROM expense WHERE date BETWEEN ? AND ?",start,end);
        long rides=scalar("SELECT COALESCE(SUM(rides),0) FROM day WHERE date BETWEEN ? AND ?",start,end);
        long allowance=scalar("SELECT COALESCE(SUM(charge_cents),0) FROM day WHERE date BETWEEN ? AND ? AND closed=1",start,end),ms=0,km=0;
        LocalDate d=LocalDate.parse(start),last=LocalDate.parse(end);if(last.isBefore(d)||java.time.temporal.ChronoUnit.DAYS.between(d,last)>3660)throw new IllegalArgumentException("Período inválido.");
        while(!d.isAfter(last)) {String key=d.toString();long[] s=shiftTotals(key);ms+=s[0];km+=s[1];d=d.plusDays(1);}
        return new long[]{income,expense,allowance,rides,ms,km};
    }
}
