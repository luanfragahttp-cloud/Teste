package br.com.visionario.app;
import android.app.*;import android.content.*;import android.os.*;import android.graphics.Bitmap;import java.io.*;import java.util.concurrent.*;
/** Exercises the real existing shift form and bridge in the disposable CI emulator. */
public final class ShiftCheck extends Instrumentation {
 ExistingScreensActivity a;
 public void onCreate(Bundle b){super.onCreate(b);start();}
 void check(boolean ok,String why)throws Exception{if(!ok)throw new Exception(why);}
 String js(String code)throws Exception{CountDownLatch l=new CountDownLatch(1);String[] s={null};runOnMainSync(()->a.web.evaluateJavascript(code,v->{s[0]=v;l.countDown();}));check(l.await(10,TimeUnit.SECONDS),"JS timeout");return s[0];}
 void click(String label)throws Exception{check("true".equals(js("(()=>{let b=[...document.querySelectorAll('button')].find(b=>b.textContent.trim()==="+org.json.JSONObject.quote(label)+");if(!b)return false;b.click();return true})()")),"Missing button: "+label);Thread.sleep(250);}
 void launch()throws Exception{a=(ExistingScreensActivity)startActivitySync(new Intent(getTargetContext(),ExistingScreensActivity.class).putExtra("screen","shift").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));Thread.sleep(1800);check("true".equals(js("!!document.querySelector('.clock') || document.querySelector('#app').innerText.includes('Iniciar turno')")),"Shift screen not rendered");}
 public void onStart(){Bundle r=new Bundle();try{
  launch();click("Iniciar turno");click("Confirmar");check(a.store.openShift()==0,"Empty initial KM accepted");
  js("document.querySelector('#km').value='1000'");click("Confirmar");long id=a.store.openShift();check(id>0,"Start button failed");
  String before=js("document.querySelector('#clock').textContent");Thread.sleep(2300);String after=js("document.querySelector('#clock').textContent");check(!before.equals(after),"Visible stopwatch frozen");check(after.matches("\"[0-9]+:[0-9]{2}:[0-9]{2}\""),"Seconds absent");
  click("Pausar");String paused=js("document.querySelector('#clock').textContent");Thread.sleep(1600);check(paused.equals(js("document.querySelector('#clock').textContent")),"Pause counted as work");
  runOnMainSync(a::finish);launch();check(paused.equals(js("document.querySelector('#clock').textContent")),"Paused state lost reopening");click("Retomar");Thread.sleep(1500);check(!paused.equals(js("document.querySelector('#clock').textContent")),"Resume failed");
  File folder=new File(a.getExternalFilesDir(null),"screenshots");folder.mkdirs();Bitmap b=getUiAutomation().takeScreenshot();try(FileOutputStream f=new FileOutputStream(new File(folder,"07-stopwatch.png"))){b.compress(Bitmap.CompressFormat.PNG,100,f);}b.recycle();
  runOnMainSync(a::finish);launch();check(a.store.openShift()==id,"Active shift lost reopening");click("Encerrar");click("Confirmar");check(a.store.openShift()==id,"Empty final KM accepted");js("document.querySelector('#km').value='999'");click("Confirmar");check(a.store.openShift()==id,"Reverse KM accepted");js("document.querySelector('#km').value='1010'");click("Confirmar");check(a.store.openShift()==0,"Finish failed");check(a.store.scalar("SELECT km_end-km_start FROM shift WHERE id=?",""+id)==10000,"Distance wrong");
  click("Iniciar turno");js("document.querySelector('#km').value='1010'");click("Confirmar");check(a.store.openShift()>id,"Second shift failed");click("Encerrar");js("document.querySelector('#km').value='1015'");click("Confirmar");check(a.store.openShift()==0,"Second finish failed");
  r.putString("stream","PASS: real shift form buttons; required initial/final KM; second-by-second visible clock; pause; resume; paused/running persistence; invalid final KM; distance; multiple shifts.\n");runOnMainSync(a::finish);finish(Activity.RESULT_OK,r);
 }catch(Throwable t){r.putString("stream","FAIL: "+t+"\n");finish(Activity.RESULT_CANCELED,r);}}
}
