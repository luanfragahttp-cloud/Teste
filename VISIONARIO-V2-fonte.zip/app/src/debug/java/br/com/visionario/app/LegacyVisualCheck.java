package br.com.visionario.app;
import android.app.*;
import android.content.*;
import android.os.*;
import android.graphics.Bitmap;
import org.json.*;
import java.io.*;
import java.util.concurrent.*;

/** Runs only when explicitly launched by adb instrumentation in the disposable emulator. */
public final class LegacyVisualCheck extends Instrumentation {
    ExistingScreensActivity activity;String testDay="2026-09-27"; File folder;
    @Override public void onCreate(Bundle args){super.onCreate(args);start();}
    String js(String script)throws Exception{CountDownLatch wait=new CountDownLatch(1);String[] result={null};runOnMainSync(()->activity.web.evaluateJavascript(script,v->{result[0]=v;wait.countDown();}));if(!wait.await(10,TimeUnit.SECONDS))throw new Exception("JavaScript timeout");return result[0];}
    void check(boolean condition,String message)throws Exception{if(!condition)throw new Exception(message);}
    void capture(String name,String route)throws Exception{
        js("visualScreen("+JSONObject.quote(route)+","+JSONObject.quote(testDay)+")");Thread.sleep(1800);
        check("true".equals(js("!document.querySelector('.header.home .avatar') || getComputedStyle(document.querySelector('.header.home .avatar')).display==='block'")),"Avatar crop must be contained");
        check("true".equals(js("document.documentElement.scrollWidth<=innerWidth+1")),"Horizontal overflow on "+route);
        check("true".equals(js("!document.querySelector('.bottom-nav') || document.querySelector('.bottom-nav').getBoundingClientRect().bottom<=innerHeight+1")),"Navigation clipped on "+route);
        Bitmap bitmap=getUiAutomation().takeScreenshot();try(FileOutputStream out=new FileOutputStream(new File(folder,name+".png"))){bitmap.compress(Bitmap.CompressFormat.PNG,100,out);}bitmap.recycle();
    }
    @Override public void onStart(){Bundle result=new Bundle();try{
        Intent intent=new Intent(getTargetContext(),ExistingScreensActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);activity=(ExistingScreensActivity)startActivitySync(intent);Thread.sleep(3000);
        folder=new File(activity.getExternalFilesDir(null),"screenshots");folder.mkdirs();
        check("true".equals(js("!!document.querySelector('.header.home')")),"Home failed to load");
        capture("00-empty-home","home");
        js("visualScreen('gain','"+testDay+"');document.querySelector('#gain-value').value='180,00';saveGain()");
        check(activity.store.scalar("SELECT cents FROM income WHERE date=? AND source_id=1",testDay)==18000,"Gain did not persist");
        js("visualScreen('gain','"+testDay+"');document.querySelector('#gain-value').value='181,00';saveGain()");
        check(activity.store.scalar("SELECT cents FROM income WHERE date=? AND source_id=1",testDay)==18100,"Daily gain must replace previous amount");
        js("visualScreen('expense','"+testDay+"');document.querySelector('#expense-value').value='0';saveExpense()");
        check(activity.store.scalar("SELECT COUNT(*) FROM expense WHERE date=?",testDay)==0,"Zero expense was accepted");
        js("document.querySelector('#expense-value').value='80,00';document.querySelector('#expense-note').value='Abastecimento';saveExpense()");
        check(activity.store.scalar("SELECT SUM(cents) FROM expense WHERE date=?",testDay)==8000,"Expense did not persist");
        activity.store.income(testDay,1,18000);activity.store.income(testDay,2,9550);activity.store.income(testDay,3,11000);activity.store.income(testDay,4,4300);activity.store.expense(testDay,"Alimentação",640,"Café");
        js("visualScreen('closing','"+testDay+"');document.querySelector('#rides').value='12';saveClosing()");
        check(activity.store.scalar("SELECT rides FROM day WHERE date=?",testDay)==12,"Closing did not persist");
        check(activity.store.totals(testDay,testDay)[0]==42850,"Wrong income total");
        check(activity.store.totals(testDay,testDay)[1]==8640,"Wrong expense total");
        check(activity.store.totals(testDay,testDay)[2]==0,"Sunday should not charge daily allowance");
        activity.store.start(testDay,100000000);activity.store.pause(false);activity.store.pause(true);activity.store.finish(100050000);
        check(activity.store.shiftTotals(testDay)[1]==50000,"Wrong shift distance");
        boolean invalid=false;try{activity.store.manual(testDay,1000,2000,200,100,0);}catch(Exception e){invalid=true;}check(invalid,"Reverse odometer accepted");
        js("document.querySelector('#toast').style.display='none'");
        capture("01-home","home");capture("02-gain","gain");capture("03-expense","expense");capture("04-closing","closing");capture("05-transactions","transactions");
        for(int i=21;i<27;i++){String d="2026-09-"+i;activity.store.income(d,1,12000+(i-20)*1000);activity.store.income(d,2,6500+(i-20)*500);activity.store.expense(d,"Gasolina",7000+(i-20)*150,"");}
        capture("06-reports","reports");capture("07-more","more");capture("08-shift","shift");capture("09-splash","splash");
        js("visualScreen('home','"+testDay+"');openDrawer()");Thread.sleep(1800);Bitmap bitmap=getUiAutomation().takeScreenshot();try(FileOutputStream out=new FileOutputStream(new File(folder,"10-menu.png"))){bitmap.compress(Bitmap.CompressFormat.PNG,100,out);}bitmap.recycle();
        result.putString("stream","PASS: install, launch, daily gain replacement, expense validation, closing, Sunday charge, shift distance, invalid odometer, UI screenshots and viewport bounds.\n");finish(Activity.RESULT_OK,result);
    }catch(Throwable e){result.putString("stream","FAIL: "+e.toString()+"\n");finish(Activity.RESULT_CANCELED,result);}}
}
