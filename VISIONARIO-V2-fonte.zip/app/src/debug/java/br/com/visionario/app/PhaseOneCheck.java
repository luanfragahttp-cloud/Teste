package br.com.visionario.app;
import android.app.*;import android.content.*;import android.content.pm.*;import android.os.*;import android.graphics.*;import android.graphics.drawable.*;import android.view.*;import android.widget.*;import android.webkit.WebView;import java.io.*;
public final class PhaseOneCheck extends Instrumentation {
 MainActivity a; File folder;
 @Override public void onCreate(Bundle args){super.onCreate(args);start();}
 void check(boolean yes,String msg)throws Exception{if(!yes)throw new Exception(msg);}
 boolean web(View v){if(v instanceof WebView)return true;if(v instanceof ViewGroup)for(int i=0;i<((ViewGroup)v).getChildCount();i++)if(web(((ViewGroup)v).getChildAt(i)))return true;return false;}
 void shot(String name)throws Exception{getUiAutomation().waitForIdle(150,3000);Bitmap b=getUiAutomation().takeScreenshot();try(FileOutputStream out=new FileOutputStream(new File(folder,name+".png"))){b.compress(Bitmap.CompressFormat.PNG,100,out);}b.recycle();}
 MainActivity launch() {return (MainActivity)startActivitySync(new Intent(getTargetContext(),MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));}
 @Override public void onStart(){Bundle r=new Bundle();try{
  folder=new File(getTargetContext().getExternalFilesDir(null),"screenshots");folder.mkdirs();
  a=launch();Thread.sleep(250);check(a.safeRoot.findViewWithTag("native-splash")!=null,"Missing native splash");check(!web(a.safeRoot),"WebView inside launcher");shot("01-splash");Thread.sleep(2100);
  check(a.homeReady,"Splash did not lead to Home");check(a.safeRoot.findViewWithTag("native-home")!=null,"Missing native Home");check(!web(a.safeRoot),"Home must be native");
  ApplicationInfo info=getTargetContext().getApplicationInfo();check("VI$IONARIO".contentEquals(getTargetContext().getPackageManager().getApplicationLabel(info)),"Wrong launcher label");check(getTargetContext().getDrawable(info.icon) instanceof AdaptiveIconDrawable,"Not adaptive icon");
  runOnMainSync(()->{a.day="2026-09-29";a.renderHome();});Thread.sleep(500);shot("02-home-empty");
  a.store.income("2026-09-29",1,42850);a.store.expense("2026-09-29","Combustível",8640,"Teste de persistência");runOnMainSync(()->a.renderHome());Thread.sleep(500);shot("03-home-values");
  check(a.store.totals("2026-09-29","2026-09-29")[0]==42850,"Gain total wrong");
  for(String route:new String[]{"gain","expense","closing","reports","shift","transactions","more","notifications"}){ActivityMonitor monitor=addMonitor(ExistingScreensActivity.class.getName(),null,false);runOnMainSync(()->a.open(route));Activity screen=waitForMonitorWithTimeout(monitor,15000);check(screen!=null,"Broken route "+route);check(route.equals(screen.getIntent().getStringExtra("screen")),"Wrong route "+route);Thread.sleep(500);runOnMainSync(screen::finish);removeMonitor(monitor);waitForIdleSync();Thread.sleep(800);}
  runOnMainSync(a::finish);a=launch();Thread.sleep(2500);check(a.store.totals("2026-09-29","2026-09-29")[0]==42850,"Data lost on recreation");
  runOnMainSync(()->{a.day="2026-09-29";a.renderHome();});Thread.sleep(350);View nav=a.safeRoot.findViewWithTag("bottom-navigation");int[] pos=new int[2];nav.getLocationOnScreen(pos);check(pos[1]+nav.getHeight()<=a.getWindow().getDecorView().getHeight(),"Bottom navigation clipped");
  Activity icons=startActivitySync(new Intent(getTargetContext(),IconPreviewActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));Thread.sleep(650);shot("04-icon-masks");runOnMainSync(icons::finish);
  r.putString("stream","PASS: native splash, native Home without WebView, exact app label, packaged adaptive icon, all Home routes, SQLite totals, data persistence, bottom navigation.\n");finish(Activity.RESULT_OK,r);
 }catch(Throwable e){r.putString("stream","FAIL: "+e.toString()+"\n");finish(Activity.RESULT_CANCELED,r);}}
}
