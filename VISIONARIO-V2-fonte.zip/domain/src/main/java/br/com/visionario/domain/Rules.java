package br.com.visionario.domain;

import java.time.*;
import java.time.format.*;
import java.util.Locale;

/** All money is stored as integer cents, time as epoch milliseconds, and mileage as metres. */
public final class Rules {
    private Rules() {}
    public static long cents(String input) {
        String s = input.trim().replace("R$", "").replace(" ", "");
        if (s.isEmpty()) return 0;
        if (s.matches("\\d+")) return Math.multiplyExact(Long.parseLong(s), 100);
        if (s.matches("\\d{1,3}(\\.\\d{3})*,\\d{1,2}|\\d+,\\d{1,2}")) {
            String[] p = s.replace(".", "").split(",");
            return Math.addExact(Math.multiplyExact(Long.parseLong(p[0]), 100), Integer.parseInt((p[1] + "0").substring(0, 2)));
        }
        throw new IllegalArgumentException("Valor inválido. Use 150,00.");
    }
    public static String money(long cents) {
        return String.format(new Locale("pt", "BR"), "R$ %,.2f", cents / 100.0);
    }
    public static String time(String input) {
        String s = input.trim();
        if (s.matches("\\d{4}")) s = s.substring(0, 2) + ":" + s.substring(2);
        if (!s.matches("\\d{2}:\\d{2}")) throw new IllegalArgumentException("Hora inválida. Use 0800 ou 08:00.");
        try { LocalTime.parse(s, DateTimeFormatter.ofPattern("HH:mm")); } catch (DateTimeException e) { throw new IllegalArgumentException("Hora inválida.", e); }
        return s;
    }
    public static int minutes(String input) {
        if (input.trim().isEmpty()) return 0;
        int n = Integer.parseInt(input.trim());
        if (n < 0) throw new IllegalArgumentException("Pausa negativa.");
        return n;
    }
    public static long metres(String input) {
        String s = input.trim();
        if (s.matches("\\d{1,3}(\\.\\d{3})+")) s = s.replace(".", "");
        else s = s.replace(",", ".");
        if (!s.matches("\\d+(\\.\\d{1,3})?")) throw new IllegalArgumentException("KM inválido.");
        java.math.BigDecimal n = new java.math.BigDecimal(s).multiply(new java.math.BigDecimal("1000"));
        return n.longValueExact();
    }
    public static void kmRange(long start, long end) {
        if (end < start) throw new IllegalArgumentException("KM final não pode ser menor que o inicial.");
    }
    public static long worked(long start, long end, long paused) {
        if (end < start || paused < 0 || paused > end - start) throw new IllegalArgumentException("Horários ou pausas inválidos.");
        return end - start - paused;
    }
    public static boolean due(LocalDate date, int weekday) { return date.getDayOfWeek().getValue() == weekday; }
    public static long allowance(LocalDate date, long daily, long pda, boolean pdaActive, int pdaWeekday) {
        return (date.getDayOfWeek() == DayOfWeek.SUNDAY ? 0 : daily) + (pdaActive && due(date, pdaWeekday) ? pda : 0);
    }
    public static String duration(long ms) { long m = Math.max(0, ms) / 60000; return String.format(Locale.ROOT, "%02d:%02d", m / 60, m % 60); }
}
