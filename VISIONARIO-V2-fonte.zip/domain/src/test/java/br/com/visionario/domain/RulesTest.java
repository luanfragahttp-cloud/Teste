package br.com.visionario.domain;
import java.time.LocalDate;
public final class RulesTest {
    static void eq(Object expected,Object actual){if(!expected.equals(actual))throw new AssertionError(expected+" != "+actual);}
    static void reject(Runnable r){try{r.run();throw new AssertionError("Expected rejection");}catch(IllegalArgumentException expected){}}
    public static void main(String[] args){
        eq(21800L,Rules.cents("218,00"));eq(15050L,Rules.cents("R$ 150,50"));eq("08:00",Rules.time("0800"));
        eq(1200L,Rules.metres("1,2"));eq(100000000L,Rules.metres("100.000"));Rules.kmRange(100000,110000);reject(()->Rules.kmRange(110000,100000));
        eq(7*3600000L,Rules.worked(0,8*3600000L,3600000L));reject(()->Rules.worked(10,0,0));
        eq(21800L,Rules.allowance(LocalDate.of(2026,9,28),21800,15000,true,3));
        eq(36800L,Rules.allowance(LocalDate.of(2026,9,30),21800,15000,true,3));
        eq(0L,Rules.allowance(LocalDate.of(2026,10,4),21800,15000,true,3));
        reject(()->Rules.cents("12.34"));reject(()->Rules.time("2560"));System.out.println("RulesTest OK");
    }
}
