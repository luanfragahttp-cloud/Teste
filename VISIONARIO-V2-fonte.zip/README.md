# VI$IONARIO — refatoração nativa da V1, Fase 1

Continuação do projeto existente. Não cria outro aplicativo. ApplicationId e assinatura anteriores são preservados; somente o nome exibido foi corrigido para VI$IONARIO. versionCode=3.

Fase 1 implementada: abertura e Home com Views/Canvas nativos Android, ícone adaptativo cartoon (foreground/background, icon/roundIcon e cinco qualificadores de densidade), data brasileira, três cartões financeiros, ações 2×2, acesso a Turno/KM e navegação inferior. A arte original é enquadrada por Drawables; não é regenerada nem substituída por outro personagem.

SQLite `visionario-v1.db` e schema v1 permanecem intactos. Totais da Home incluem os custos recorrentes já aplicados no fechamento. Nenhuma mudança nas regras financeiras nesta etapa.

Durante a migração por fases solicitada, as telas anteriores são mantidas em ExistingScreensActivity para não remover funções. Essa atividade ainda contém a implementação WebView anterior e será substituída nas fases seguintes. O launcher/MainActivity, Home e splash não usam WebView. Preferências conservam o arquivo br.com.visionario.app.MainActivity.xml antigo.

Esta é uma prévia de Fase 1, NÃO o APK final completo da V1. Fases 2–9 aguardam comparação visual da Fase 1.

## Verificação

`bash test-domain.sh` (inclui Gradle clean quando disponível), `gradle --no-daemon :app:assembleDebug :app:assembleRelease`, `bash verify-android.sh` em emulador. Teste PhaseOneCheck valida splash/Home nativas, nome, ícone adaptativo empacotado, atalhos, persistência e navegação. As capturas usam dados descartáveis apenas no emulador; a variante release não inclui testes nem dados demonstrativos.
