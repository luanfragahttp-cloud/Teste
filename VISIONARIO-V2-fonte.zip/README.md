# VI$IONARIO 2 — Android sem login

Interface refeita a partir das referências aprovadas: cartões compactos verde/vermelho/azul, atalhos em grade, origens e categorias visuais, navegação inferior, relatórios com gráficos, personagem cartoon e menu lateral.

O aplicativo usa um WebView local, sem permissão de internet, com banco SQLite nativo. Salvar ganho substitui o total diário da origem; despesas são lançamentos separados. O fechamento aplica diária/PDA uma única vez, com preservação dos valores antigos. Mantém cronômetro, pausas, turnos manuais e KM.

Inclui perfil e veículo locais, meta diária, tema claro/escuro e exportação/restauração de backup JSON via seletor do Android. Avisos são internos; não há notificações remotas nem login.

Application ID: br.com.visionario.v2. Instala separadamente da V1 para preservar os dados existentes. A chave privada de assinatura da V2 é guardada fora do repositório para permitir futuras atualizações.

## Compilar e verificar
JDK 17, Gradle 8.9, Android SDK 35 e Build Tools 35.0.0.
`gradle :app:assembleDebug :app:assembleRelease`
`bash test-domain.sh`
Em emulador Android: `bash verify-android.sh`. A instrumentação de teste só existe na variante debug. O APK de entrega é release assinado; não contém a instrumentação nem dados demonstrativos.

As imagens de referência completas estão nos assets, usadas apenas como origem visual da arte cartoon por enquadramento CSS. Os formulários, cartões, gráficos e navegação são componentes reais. As capturas do emulador permitem avaliar diferenças de proporção, ícones e tipografia em relação aos mockups.
