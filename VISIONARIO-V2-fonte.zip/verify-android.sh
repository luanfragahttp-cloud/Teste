#!/usr/bin/env bash
set -euo pipefail
adb install -r app/build/outputs/apk/debug/app-debug.apk
adb shell settings put system font_scale 1.0
adb shell wm size 1080x2400
adb shell wm density 420
adb shell am instrument -w br.com.visionario.v2/br.com.visionario.app.PhaseOneCheck | tee android-test-result.txt
grep '^PASS:' android-test-result.txt
mkdir -p screenshots
adb pull /sdcard/Android/data/br.com.visionario.v2/files/screenshots/. screenshots/
adb shell am force-stop br.com.visionario.v2
adb shell monkey -p br.com.visionario.v2 -c android.intent.category.LAUNCHER 1
sleep 3
adb shell screencap -p /sdcard/phase1-reopened.png
adb pull /sdcard/phase1-reopened.png screenshots/05-reopened.png
adb shell input keyevent KEYCODE_HOME
adb shell input swipe 540 2100 540 400 500
sleep 1
adb shell screencap -p /sdcard/phase1-launcher.png
adb pull /sdcard/phase1-launcher.png screenshots/06-launcher.png
adb logcat -d -s AndroidRuntime:E > android-crashes.txt
if grep 'FATAL EXCEPTION' android-crashes.txt; then exit 1; fi
