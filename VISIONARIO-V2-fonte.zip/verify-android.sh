#!/usr/bin/env bash
set -euo pipefail
adb install -r app/build/outputs/apk/debug/app-debug.apk
adb shell settings put system font_scale 1.0
adb shell wm size 1080x2400
adb shell wm density 420
adb shell am instrument -w br.com.visionario.v2/br.com.visionario.app.VisualCheck | tee android-test-result.txt
grep '^PASS:' android-test-result.txt
mkdir -p screenshots
adb pull /sdcard/Android/data/br.com.visionario.v2/files/screenshots/. screenshots/
adb logcat -d -s AndroidRuntime:E > android-crashes.txt
if grep 'FATAL EXCEPTION' android-crashes.txt; then exit 1; fi
